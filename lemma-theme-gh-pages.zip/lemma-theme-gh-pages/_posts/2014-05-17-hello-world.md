---
title: Hello, world!
tags: [Announcement, Test]
---

Treditional programmer used to, and still do, print this sentence to test whether their program work or not. So why not test again :P

You'll find other examples in the following posts.

But for now, hello!
