Lemma Theme
===========

Lemma is yet another simple responsive theme for Jekyll.


License
-------

- MIT
